Instrucciones para Asure ID
=======================

1. Extraiga todo el contenido de este ZIP en una carpeta de su elección
   (por ejemplo: C:\Carnets)

2. En Asure ID:
   a. Importe el archivo datos_carnets.csv
   b. En la plantilla del carnet, configure la foto:
      - En "Propiedades de la foto", active "Utilizar un origen de datos de carpeta"
      - En "Origen de datos", seleccione la carpeta "imagenes/fotos" donde extrajo el ZIP
      - El campo "ruta_foto" del CSV contiene el nombre del archivo de cada foto

3. Las fotos se encuentran en la carpeta imagenes/fotos
   - Cada foto tiene el formato: NOMBRE_CEDULA.jpg
   (ejemplo: MARIA_L._VILLARREAL_67151417.jpg)

Nota: Es importante mantener la estructura de carpetas tal como está:
- datos_carnets.csv
- imagenes/
  └── fotos/
